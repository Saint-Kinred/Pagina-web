
package modelo;


public class inmueble {
 String estado;
 String tipo;
 String ciudad;
 String codigo;
 
 public inmueble(){
     
 }
  public inmueble(String estado,String tipo,String ciudad,String codigo){
      this.estado=estado;
      this.tipo=tipo;
      this.ciudad=ciudad;
      this.codigo=codigo;
   }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
  
  
}
