
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class inmuebleDAO {
    conexion cn= new conexion();
    Connection con;
    PreparedStatement ps;
    boolean rta=false;
    ResultSet rs;
    public boolean ingresar(String estado, String tipo,String cuidad,String codigo){
       String sql="INSERT INTO inmueble(estado,tipo,ciudad,codigo) VALUES(?,?,?,?)";
       try{ 
           
           con=cn.conexion();
           ps=con.prepareStatement(sql);
           ps.setString(1,estado);
           ps.setString(2,tipo);
           ps.setString(3,cuidad);
           ps.setString(4,codigo);
           ps.executeUpdate();
           con.close();
           rta= true;
           
       }catch(Exception e){
           
       }
       return rta;
    }
    
    
    
    public List listar(String estado,String tipo,String ciudad){
       String sql="select * from inmueble";
       List<inmueble>lista= new ArrayList<>();
       try{
         con=cn.conexion();
         ps=con.prepareStatement(sql);
         ps.setString(1, estado);
         ps.setString(2, tipo);
         ps.setString(3, ciudad);
         rs=ps.executeQuery();
         while(rs.next()){
             inmueble in=new inmueble();
             in.setEstado(rs.getString(1));
             in.setTipo(rs.getString(2));
             in.setCiudad(rs.getString(3));
             in.setCodigo(rs.getString(4));
             lista.add(in);
             con.close();
         }
       }catch(Exception e){
           
       }
       return lista;
       
    }
    
    
    public inmueble listarCodigo(String codigo){
        inmueble in=new inmueble();
        String sql="select * from inmueble where codigo="+codigo;
        try{
            con=cn.conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                in.setEstado(rs.getString(1));
                in.setTipo(rs.getString(2));
                in.setCiudad(rs.getString(3));   
            }
        }catch(Exception e){
            
        }
        return in;
    }
    
    public boolean actualizar(String estado, String tipo, String ciudad, String codigo){
       String sql="UPDATE inmueble SET estado=?,tipo=?,ciudad=? WHERE codigo=?";
       try{ 
           
           con=cn.conexion();
           ps=con.prepareStatement(sql);
           ps.setString(1,estado);
           ps.setString(2,tipo);
           ps.setString(3,ciudad);
           ps.setString(4,codigo);
           ps.executeUpdate();
           con.close();
           rta= true;
           
       }catch(Exception e){
           
       }
       return rta;  
    }
    
    public boolean borrar(String codigo){
        String sql="delete from inmueble where codigo="+codigo;
        try{
            con=cn.conexion();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
            con.close();
            rta=true;
        }catch (Exception e){
            
        }
        return rta;
    }
}
