
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


 
public class usuarioDAO {
    conexion cn= new conexion();
    Connection con;
    PreparedStatement ps;
    boolean rta=false;
    ResultSet rs;
    public boolean ingresar(String nombre, String apellido,String dni,String email){
       String sql="INSERT INTO usuario(Nombre,Apellido,Dni,Correo) VALUES(?,?,?,?)";
       try{ 
           
           con=cn.conexion();
           ps=con.prepareStatement(sql);
           ps.setString(1,nombre);
           ps.setString(2,apellido);
           ps.setString(3,dni);
           ps.setString(4,email);
           ps.executeUpdate();
           con.close();
           rta= true;
           
       }catch(Exception e){
           
       }
       return rta;
    }
    
    
    
    public usuario2 validar(String email){
        usuario2 us=new usuario2();
        String sql="select * from usuario where Correo=?";
        try{
           con=cn.conexion();
           ps=con.prepareStatement(sql);
           ps.setString(1,email);   
           rs=ps.executeQuery();
           while(rs.next()){
           us.setEmail(rs.getString("Correo"));
           }
        }catch(Exception e){
          
        }
        return us;
    }
    
}
