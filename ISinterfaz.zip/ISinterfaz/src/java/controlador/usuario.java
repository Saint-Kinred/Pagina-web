
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.usuario2;
import modelo.usuarioDAO;


@WebServlet(name = "usuario", urlPatterns = {"/usuario"})
public class usuario extends HttpServlet {

 usuarioDAO udao=new usuarioDAO();
 usuario2 us=new usuario2();
 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
    }

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String email=request.getParameter("correo");
      
       us= udao.validar(email);
       if (us.getEmail()!=null){
           request.getRequestDispatcher("principal.jsp").forward(request,response);
       }else{
           request.getRequestDispatcher("Ingresar.jsp").forward(request,response);
       }
     
}

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        boolean rta;
        String nombre=request.getParameter("nombre");
        String apellido=request.getParameter("apellido");
        String dni=request.getParameter("dni");
        String email=request.getParameter("correo");
        
        rta=udao.ingresar(nombre, apellido, dni, email);
       if(rta==true){
           try(PrintWriter out= response.getWriter()){
            
            out.println("Ingreso exitoso"); 
        } 
       } else{
             try(PrintWriter out= response.getWriter()){
            response.setContentType("text/html;charset=UTF-8");  
            
            out.println("Error al ingresar"); 
        } 
       }
       
    }

  
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
