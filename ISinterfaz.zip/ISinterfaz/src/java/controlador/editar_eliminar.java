/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.inmueble;
import modelo.inmuebleDAO;

/**
 *
 * @author chann
 */
@WebServlet(name = "editar_eliminar", urlPatterns = {"/editar_eliminar"})
public class editar_eliminar extends HttpServlet {
inmuebleDAO indao=new inmuebleDAO();
inmueble in=new inmueble();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
    }

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
              String codigo=request.getParameter("codigo");
             boolean rta=indao.borrar(codigo);
               if(rta==true){
           try(PrintWriter out= response.getWriter()){
            
            out.println("Inmueble eliminado"); 
        } 
       } else{
             try(PrintWriter out= response.getWriter()){
            response.setContentType("text/html;charset=UTF-8");  
            
            out.println("Error al eliminar"); 
        }
       }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String estado;
        String e=request.getParameter("estado");
        String tipo;
        String t=request.getParameter("tipo");
        String ciudad;
        String c=request.getParameter("ciudad");
        String codigo=request.getParameter("codigo");
        
        if(e.equalsIgnoreCase("nuevo")){
            estado="nuevo";
        }else if(e.equalsIgnoreCase("usado")){
            estado="usado";
        }else{
            estado="arriendo";
        }
        
        
        if(t.equalsIgnoreCase("casa")){
            tipo="casa";
        }else if(t.equalsIgnoreCase("apartamento")){
            tipo="apartamento";
        }else{
            tipo="finca";
        }
        
         if(c.equalsIgnoreCase("bogota")){
            ciudad="Bogota";
        }else if(c.equalsIgnoreCase("medellin")){
            ciudad="Medellin";
        }else{
            ciudad="Cali";
        } 
       
        boolean rta=indao.actualizar(estado, tipo, ciudad, codigo);
        
          if(rta==true){
           try(PrintWriter out= response.getWriter()){
            
            out.println("Actualizacion exitosa"); 
        } 
       } else{
             try(PrintWriter out= response.getWriter()){
            response.setContentType("text/html;charset=UTF-8");  
            
            out.println("Error al acttualizar"); 
        }
       }
        
    } 

 
    @Override
    public String getServletInfo() {
        return "Short description";
    }


}
