/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.inmueble;
import modelo.inmuebleDAO;


/**
 *
 * @author chann
 */
@WebServlet(name = "inmuebleControlador", urlPatterns = {"/inmuebleControlador"})
public class inmuebleControlador extends HttpServlet {

    inmuebleDAO indao=new inmuebleDAO();
    inmueble in=new inmueble();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {    
    }

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           boolean rta;
        String estado;
        String e=request.getParameter("estado");
        String tipo;
        String t=request.getParameter("tipo");
        String ciudad;
        String c=request.getParameter("ciudad");
        
        if(e.equalsIgnoreCase("nuevo")){
            estado="nuevo";
        }else if(e.equalsIgnoreCase("usado")){
            estado="usado";
        }else{
            estado="arriendo";
        }
        
        
        if(t.equalsIgnoreCase("casa")){
            tipo="casa";
        }else if(t.equalsIgnoreCase("apartamento")){
            tipo="apartamento";
        }else{
            tipo="finca";
        }
        
         if(c.equalsIgnoreCase("bogota")){
            ciudad="Bogota";
        }else if(c.equalsIgnoreCase("medellin")){
            ciudad="Medellin";
        }else{
            ciudad="Cali";
        } 
        List lista=indao.listar(estado, tipo, ciudad);
        /*
        request.setAttribute("inmuebles", lista);
        request.getRequestDispatcher("inmuebleMostrar.jsp").forward(request, response);*/   
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        boolean rta;
        String estado;
        String e=request.getParameter("estado");
        String tipo;
        String t=request.getParameter("tipo");
        String ciudad;
        String c=request.getParameter("ciudad");
        String codigo=request.getParameter("codigo");
        
        if(e.equalsIgnoreCase("nuevo")){
            estado="nuevo";
        }else if(e.equalsIgnoreCase("usado")){
            estado="usado";
        }else{
            estado="arriendo";
        }
        
        
        if(t.equalsIgnoreCase("casa")){
            tipo="casa";
        }else if(t.equalsIgnoreCase("apartamento")){
            tipo="apartamento";
        }else{
            tipo="finca";
        }
        
         if(c.equalsIgnoreCase("bogota")){
            ciudad="Bogota";
        }else if(c.equalsIgnoreCase("medellin")){
            ciudad="Medellin";
        }else{
            ciudad="Cali";
        } 
        
       
         rta=indao.ingresar(estado,tipo,ciudad,codigo);
         
          if(rta==true){
           try(PrintWriter out= response.getWriter()){
            
            out.println("Ingreso exitoso"); 
        } 
       } else{
             try(PrintWriter out= response.getWriter()){
            response.setContentType("text/html;charset=UTF-8");  
            
            out.println("Error al ingresar"); 
        } 
       }
    } 
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
